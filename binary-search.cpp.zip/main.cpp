/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    
    int low=0, mid,high=10,num,i,arr[10],n;
    
    
    cout<<"enter the no. in ascending order\t";
    for(i=0;i<10;i++){
        cin>>arr[i];
    }
    cout<<"enter the element u want to search\t";
    cin>>num;
    
    while(low<=high){
    mid=(low+high)/2;
if(arr[mid]==num){
    cout<<"\nThe number, "<<num<<" found at Position "<<mid+1;
    break;
}
else if(arr[mid]<num)
    low=mid+1;

else
    high=mid-1;
    mid=(low+high)/2;

}


if(low>high){
    cout<<"element not found";
    cout<<endl;
}
    return 0;
}

